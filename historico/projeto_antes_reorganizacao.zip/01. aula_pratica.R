# REDES DE INTERAÇÕES ECOLÓGICAS NO R ----
# Público: graduação em Ciências Biológicas | Duas aulas de 3 horas.
# Pré-requisitos: vetores, matrizes, data.frames e execução de linhas no RStudio.
# Abra interactions_ufpa.Rproj; na primeira utilização execute 00. preparar.R.
# Em aula, selecione cada seção e use Ctrl+Enter. Pare nas perguntas ANTES de rodar.
# Objetivo: passar de uma pergunta ecológica a dados, grafo, métrica e interpretação.
# Todos os desenhos de redes são produzidos com igraph; gráficos de métricas,
# com ggplot2. Organização, base R e tema seguem lucas-r-ggplot-style.
# Fontes de inspiração, não transcrição dos roteiros:
# https://mlurgi.github.io/networks_for_r/
# https://fukamilab.github.io/BIO202/09-B-networks.html
# Documentação e referências adicionais no guia_aula.html.

# 0. Preparação | 10 min ----
if (!file.exists('interactions_ufpa.Rproj')) stop('Abra o projeto .Rproj primeiro.')
versao_r <- paste(R.version$major, strsplit(R.version$minor, '.', fixed = TRUE)[[1]][1], sep = '.')
lib_usuario <- file.path(Sys.getenv('USERPROFILE'), 'AppData', 'Local',
                         'R', 'win-library', versao_r)
.libPaths(c('biblioteca_R', lib_usuario, .libPaths()))
pacotes <- c('igraph', 'readxl', 'ggplot2', 'vegan', 'bipartite')
faltantes <- pacotes[!vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltantes)) stop('Execute 00. preparar.R. Faltam: ', paste(faltantes, collapse = ', '))
library(igraph)
library(ggplot2)
# Usamos vegan:: e bipartite:: para evitar conflitos entre nomes de funções.
set.seed(20261101)
for (pasta in c('data', 'results', 'figures')) dir.create(pasta, showWarnings = FALSE)
source('R/apoio.R', encoding = 'UTF-8')

# 1. Do caderno de campo à matriz | 25 min ----
# PERGUNTA: muitas visitas significam muitos parceiros?
# Recorte REAL de polinizacao1.xls: primeiras quatro plantas e os cinco
# visitantes com maior total de registros nessas plantas. Critério didático,
# não amostra aleatória: as métricas deste recorte não descrevem a rede completa.
m_polinizacao <- ler_matriz('polinizacao1.xls', 'originai', 'A1:CY13')
plantas_aula <- rownames(m_polinizacao)[1:4]
ordem_visitantes <- order(colSums(m_polinizacao[plantas_aula, ]), decreasing = TRUE)
m_aula <- m_polinizacao[plantas_aula, ordem_visitantes[1:5], drop = FALSE]
write.csv(m_aula, 'data/recorte_aula_polinizacao.csv')
# Linhas = plantas; colunas = visitantes; células = registros originais.
# Zero = nenhuma visita registrada; não assumimos esforço igual.

m_aula
b_aula <- 1L * (m_aula > 0)  # Mesma rede, agora apenas presença/ausência.
b_aula
# PREVEJA: qual planta tem mais parceiros? E mais visitas?
rowSums(b_aula)
rowSums(m_aula)

# Uma lista de arestas registra cada par e seu peso.
posicoes <- which(m_aula > 0, arr.ind = TRUE)
arestas <- data.frame(planta = rownames(m_aula)[posicoes[, 1]],
                     visitante = colnames(m_aula)[posicoes[, 2]],
                     visitas = m_aula[posicoes])
arestas
# Exercício 1: altere uma célula zero para 1 e antecipe o efeito sobre grau e força.

# 2. Construir e desenhar o grafo | 20 min ----
g_aula <- rede_bipartida(m_aula, c('Plantas', 'Visitantes'))
g_aula
V(g_aula)$type  # FALSE = linhas; TRUE = colunas. Não é sinal de benefício/prejuízo.
E(g_aula)$weight
desenhar_rede(g_aula, 'Quem visita quem?')
exportar_rede(g_aula, '01_rede_didatica', 'Quem visita quem?')
# Duas guildas e ligações apenas entre elas definem uma rede bipartida.
# Uma rede pode ser bipartida e antagonista (por exemplo, herbivoria).
# O grafo aqui é não direcionado: representa associação entre pares.
# Espessura da linha representa observações, não intensidade do efeito ecológico.

# 3. Métricas da rede: calcule antes de usar funções | 25 min ----
P <- nrow(m_aula)
A <- ncol(m_aula)
S <- P + A                  # Número de nós das duas guildas.
L <- sum(m_aula > 0)         # Pares distintos; NÃO sum(m_aula).
C <- L / (P * A)            # Conectância bipartida, entre 0 e 1.
grau_medio <- 2 * L / S     # Cada aresta contribui a dois graus.
ligacoes_por_no <- L / S    # Outra estatística; não é o grau médio não direcionado.
c(P = P, A = A, S = S, L = L, C = C, grau_medio = grau_medio,
  ligacoes_por_no = ligacoes_por_no, visitas = sum(m_aula))
stopifnot(vcount(g_aula) == S, ecount(g_aula) == L,
          sum(degree(g_aula)) == 2 * L)
# Gabarito calculado a partir do recorte original:
print(metricas_rede(m_aula))
write.csv(metricas_rede(m_aula), 'results/gabarito_recorte.csv', row.names = FALSE)
edge_density(g_aula)
# DISCUTA: por que edge_density difere de C?
# Ela usa todos os pares de nós: S*(S-1)/2. Isso inclui pares da mesma guilda,
# biologicamente proibidos neste modelo. Use P*A para esta rede bipartida.
# Exercício 2: dobre todos os pesos. O que muda? Confira com metricas_rede().
metricas_rede(2 * m_aula)

# 4. Métricas dos nós e caminhos | 25 min ----
nos_aula <- metricas_nos(g_aula)
nos_aula
# Grau k_i = número de parceiros. Força s_i = soma dos pesos dos parceiros.
# Intermediação soma as frações de caminhos mínimos que passam por cada nó.
# Centralidade harmônica soma 1/distância: nós inalcançáveis contribuem zero.
# Ela é útil em redes desconectadas; centralidade não comprova espécie-chave.
# Nas métricas de caminhos, weights=NA ignora os pesos e conta passos.
distances(g_aula, weights = NA)[1:4, 1:4]
components(g_aula)$no

# Se frequência fosse interpretada como facilidade de conexão, uma escolha
# possível seria custo=1/frequência. Essa é uma HIPÓTESE, não uma conversão universal.
nos_aula$intermediacao_custo <- betweenness(g_aula,
  weights = 1 / E(g_aula)$weight, normalized = TRUE)
nos_aula[, c('nome', 'grau', 'forca', 'intermediacao', 'intermediacao_custo')]
# Nunca deixar weights=NULL sem pensar: igraph pode usar frequências como DISTÂNCIAS.

plot_data <- nos_aula
# Códigos curtos no gráfico; nomes completos preservados na tabela.
plot_data$codigo <- paste0(ifelse(plot_data$grupo == 'Plantas', 'P', 'V'),
                            ave(seq_len(nrow(plot_data)), plot_data$grupo, FUN = seq_along))
write.csv(plot_data, 'results/legenda_recorte.csv', row.names = FALSE)
plot_data$grupo <- factor(plot_data$grupo, levels = c('Plantas', 'Visitantes'))
grafico_grau <- ggplot(plot_data, aes(x = grau, y = forca, colour = grupo)) +
  geom_point(size = 3) +
  geom_text(aes(label = codigo), nudge_y = 0.7, size = 3, show.legend = FALSE) +
  scale_colour_manual(values = c(Plantas = '#0072B2', Visitantes = '#D55E00')) +
  scale_x_continuous(breaks = seq_len(max(plot_data$grau))) +
  scale_y_continuous(expand = expansion(mult = c(0.08, 0.18))) +
  labs(x = 'Número de parceiros (grau)', y = 'Número de visitas (força)',
       colour = 'Guilda', title = 'Grau e força respondem a perguntas diferentes') +
  tema_aula()
print(grafico_grau)
salvar_grafico(grafico_grau, '02_grau_forca')

# 5. Dos anexos às redes reais | 35 min ----
source('R/importar_dados.R', encoding = 'UTF-8')
lapply(matrizes, dim)
# Consulte as abas info dos arquivos originais: como cada ligação foi observada?
# Polinização: visitantes florais, não uma medição direta da deposição de pólen.
# Dispersão: amostras fecais com sementes, não sucesso de estabelecimento de plantas.
# Herbivoria: presença/ausência de consumo. Sua força é igual ao grau.
# O arquivo ectoparasitismo.xlsx está ilegível e não é usado como dado real.
# Dispersão tem duas linhas Araceae 1: não as chamamos de duas espécies confirmadas.
# Compare sensibilidade_nomes: manter linhas vs. somar registros do mesmo nome.
sensibilidade_nomes

resumo <- do.call(rbind, lapply(matrizes, metricas_rede))
resumo$rede <- rownames(resumo)
rownames(resumo) <- NULL
print(resumo)
write.csv(resumo, 'results/metricas_redes.csv', row.names = FALSE)
redes <- lapply(matrizes, rede_bipartida)
for (nome in names(redes)) {
  # Muitos rótulos tornam uma rede completa ilegível; tabelas preservam os nomes.
  exportar_rede(redes[[nome]], paste0('03_', nome), paste('Rede de', nome), rotulos = FALSE)
  write.csv(metricas_nos(redes[[nome]]), file.path('results', paste0('nos_', nome, '.csv')),
            row.names = FALSE)
}

# Recorte apenas VISUAL: oito plantas mais conectadas da rede de polinização.
# Métricas principais acima foram calculadas com a matriz completa.
ordem <- order(rowSums(matrizes$polinizacao > 0), decreasing = TRUE)
recorte <- matrizes$polinizacao[ordem[1:8], , drop = FALSE]
recorte <- recorte[, colSums(recorte) > 0, drop = FALSE]
# No projetor, mostre em vez disso os parceiros de uma única planta:
planta <- rownames(matrizes$polinizacao)[ordem[2]]
parceiros <- colnames(matrizes$polinizacao)[matrizes$polinizacao[planta, ] > 0]
head(parceiros, 10)
# DISCUTA: por que comparar apenas as conectâncias destas três redes não permite
# concluir que uma interação ecológica é mais estável que outra?
# Tamanho, resolução taxonômica, protocolo e esforço de amostragem também diferem.

# 6. Caso cacau: definir corretamente os nós | 25 min ----
esforco
unique(cacau$data_padrao)
resumo_cacau <- do.call(rbind, lapply(cacau_matrizes, metricas_rede))
resumo_cacau$rede <- rownames(resumo_cacau)
rownames(resumo_cacau) <- NULL
print(resumo_cacau)
write.csv(resumo_cacau, 'results/metricas_cacau.csv', row.names = FALSE)
for (nome in names(cacau_matrizes)) {
  g <- rede_bipartida(cacau_matrizes[[nome]], c('Genótipos', 'Grupos de artrópodes'))
  exportar_rede(g, paste0('04_cacau_', nome), paste('Cacau:', nome))
}
# São quatro redes: dois sistemas x dois métodos. Não misture Flores e Aspirador.
# Os grupos têm resolução taxonômica desigual: Hemiptera, Aphididae e Cicadellidae
# podem ter hierarquia sobreposta. Confirmar se as categorias são exclusivas.
# Por isso, a unidade é o GRUPO REGISTRADO, e não riqueza de espécies.
# Exercício 3: compare os sistemas usando somente Flores; depois repita com Aspirador.
# A conclusão muda? Sem réplicas independentes e esforço conhecido, fique na descrição.
# FIM DA AULA 1: 180 min, incluindo 15 min de intervalo entre as seções 4 e 5.

# 7. Direção das interações: extensão trófica | 15 min ----
# Recorte REAL de herbivoria.xls: três plantas e seus consumidores registrados.
# Setas representam recurso -> consumidor. Não inventamos relações entre consumidores.
m_herb <- matrizes$herbivoria[1:3, , drop = FALSE]
m_herb <- m_herb[, colSums(m_herb) > 0, drop = FALSE]
g_trofica <- graph_from_biadjacency_matrix(m_herb, directed = TRUE, mode = 'out')
papel <- data.frame(especie = V(g_trofica)$name,
                    entrada = degree(g_trofica, mode = 'in'),
                    saida = degree(g_trofica, mode = 'out'))
print(papel)
# Entrada = recursos consumidos; saída = consumidores do recurso.
# Neste recorte bipartido não há consumidores intermediários registrados.
# Ausência de predadores na planilha não demonstra posição de topo na comunidade.
write.csv(papel, 'results/direcao_herbivoria.csv', row.names = FALSE)
png('figures/05_teia_trofica.png', width = 2000, height = 1400, res = 180)
xy <- layout_as_bipartite(g_trofica)[, c(2, 1)]
plot(g_trofica, layout = xy, vertex.color = ifelse(V(g_trofica)$type, '#D55E00', '#0072B2'),
     vertex.size = 7, vertex.label.cex = 0.65, vertex.label.family = 'sans',
     vertex.label.color = 'black', vertex.label.dist = 3,
     vertex.label.degree = ifelse(V(g_trofica)$type, pi, 0),
     edge.arrow.size = 0.4, margin = 0.35,
     main = 'Herbivoria: recurso → consumidor (recorte real)')
dev.off()
# Mesmo com setas, só são permitidas ligações planta -> gafanhoto:
conectancia_direcionada <- ecount(g_trofica) / (nrow(m_herb) * ncol(m_herb))
conectancia_direcionada
# S² e S(S-1) seriam denominadores de outros modelos de ligações possíveis.

# 8. Aninhamento e especialização | 25 min ----
# PERGUNTA: parceiros de nós pouco conectados são subconjuntos dos parceiros
# dos nós muito conectados? Isso é aninhamento; não significa apenas alto grau.
m <- matriz_ativa(matrizes$polinizacao)
# Na análise de padrões, excluímos margens zeradas e documentamos essa escolha.
# Na tabela descritiva anterior, todos os táxons listados foram mantidos.
nodf_observado <- nodf(m)
nodf_observado
# NODF varia de 0 a 100. Não é uma probabilidade nem um teste estatístico.
ord_l <- order(rowSums(m > 0), decreasing = TRUE)
ord_c <- order(colSums(m > 0), decreasing = TRUE)
bin_ordenada <- 1L * (m[ord_l, ord_c] > 0)
plot_data <- expand.grid(linha = seq_len(nrow(bin_ordenada)),
                         coluna = seq_len(ncol(bin_ordenada)))
plot_data$presenca <- factor(as.vector(bin_ordenada), levels = c(0, 1))
grafico_matriz <- ggplot(plot_data, aes(coluna, linha, fill = presenca)) +
  geom_tile() +
  scale_fill_manual(values = c('0' = '#F0F0F0', '1' = '#0072B2'),
                    labels = c('Não registrada', 'Registrada')) +
  scale_y_reverse() +
  labs(x = 'Visitantes ordenados por grau', y = 'Plantas ordenadas por grau',
       fill = 'Interação', title = 'A matriz ordenada revela o padrão de ocupação') +
  tema_aula()
print(grafico_matriz)
salvar_grafico(grafico_matriz, '06_matriz_ordenada')

# H2' considera distribuição dos pesos e totais marginais; grau mede parceiros.
# A função pede 'H2', mas retorna o índice padronizado H2' (0 a 1).
# Marginais são aproximações de disponibilidade de interação, não abundâncias medidas.
h2 <- bipartite::networklevel(m, index = 'H2')
d_especies <- bipartite::specieslevel(m, index = 'd')
h2
head(d_especies[[1]])
write.csv(d_especies[[1]], 'results/d_visitantes.csv')
write.csv(d_especies[[2]], 'results/d_plantas.csv')
# d' é a especialização por nó. Nenhum destes índices demonstra preferência causal.
# Não tratar a matriz binária de herbivoria como contagens de eventos.

# 9. Modularidade bipartida | 20 min ----
# PERGUNTA: existem conjuntos de recursos e parceiros que concentram ligações?
# Qb = soma[(w_ij - s_i*t_j/W) * I(mesmo módulo)] / W.
# W = peso total; s_i e t_j = totais das margens. Modelo de referência bipartido.
# Louvain do igraph usa outra modularidade; aqui calculamos com bipartite,
# mantendo o desenho com igraph.
set.seed(91)
modulos <- bipartite::computeModules(m, method = 'Beckett')
Q_bipartido <- modulos@likelihood
modulos_lista <- bipartite::listModuleInformation(modulos)
print(Q_bipartido)
print(modulos_lista)
# O objeto é guardado para explorar a composição dos módulos, sem inferir
# significância só porque o algoritmo encontrou uma partição.
saveRDS(modulos, 'results/modulos_polinizacao.rds')
particao <- tail(modulos_lista, 1)[[1]]
tabela_modulos <- do.call(rbind, lapply(seq_along(particao), function(i) {
  data.frame(id = c(paste0('R:', particao[[i]][[1]]), paste0('C:', particao[[i]][[2]])),
             modulo = i)
}))
g_modulos <- rede_bipartida(m, c('Plantas', 'Visitantes'))
V(g_modulos)$modulo <- tabela_modulos$modulo[match(V(g_modulos)$name, tabela_modulos$id)]
stopifnot(!anyNA(V(g_modulos)$modulo), !anyDuplicated(tabela_modulos$id))
cores_modulos <- grDevices::hcl.colors(length(particao), palette = 'Dark 3')
# Alinhar guildas e ordenar por módulo torna os blocos visíveis.
xy_modulos <- matrix(0, nrow = vcount(g_modulos), ncol = 2)
for (tipo in c(FALSE, TRUE)) {
  ids <- which(V(g_modulos)$type == tipo)
  ids <- ids[order(V(g_modulos)$modulo[ids])]
  xy_modulos[ids, 1] <- if (tipo) 1 else -1
  xy_modulos[ids, 2] <- seq(1, -1, length.out = length(ids))
}
png('figures/09_modulos.png', width = 2000, height = 1500, res = 180)
par(family = 'sans', mar = c(5, 1, 4, 1))
plot(g_modulos, layout = xy_modulos, vertex.label = NA,
     vertex.color = cores_modulos[V(g_modulos)$modulo], vertex.frame.color = 'white',
     vertex.shape = ifelse(V(g_modulos)$type, 'circle', 'square'),
     vertex.size = ifelse(V(g_modulos)$type, 2.5, 8),
     edge.color = adjustcolor('#576574', alpha.f = 0.35),
     edge.width = 0.4 + sqrt(E(g_modulos)$weight),
     main = 'Polinização: módulos bipartidos')
mtext('Esquerda: plantas | Direita: visitantes | Cores: módulos', side = 3, line = 0.1, cex = 0.8)
legend('bottom', inset = c(0, -0.04), xpd = TRUE,
       legend = paste('Módulo', seq_along(particao)),
       col = cores_modulos, pch = 16, ncol = 7, bty = 'n', cex = 0.75)
dev.off()
write.csv(tabela_modulos, 'results/composicao_modulos.csv', row.names = FALSE)
# Exercício 4: troque a semente e repita; a partição é exatamente a mesma?

# 10. Modelo nulo: comparar com uma expectativa explícita | 30 min ----
# Hipótese direcional definida ANTES: NODF observado é maior que sob H0?
# H0: redistribuição de contagens condicionada aos totais por linha e coluna.
# r2dtable mantém força, peso total e dimensão; NÃO mantém grau/conectância.
# Amostragem de tabelas com margens fixas: probabilidades não são uniformes
# sobre todas as tabelas. Todos os pesos precisam ser contagens inteiras.
stopifnot(all(m == round(m)))
B <- 199L  # demonstração; no projeto final use 999 ou mais, avaliando precisão.
set.seed(2026)
nulas <- r2dtable(B, rowSums(m), colSums(m))
stopifnot(all(rowSums(nulas[[1]]) == rowSums(m)),
          all(colSums(nulas[[1]]) == colSums(m)))
nodf_nulo <- vapply(nulas, nodf, numeric(1))
sd_nulo <- sd(nodf_nulo)
ses <- if (sd_nulo > 0) (nodf_observado - mean(nodf_nulo)) / sd_nulo else NA_real_
p_superior <- (1 + sum(nodf_nulo >= nodf_observado)) / (B + 1)
# Correção +1 evita p=0. Resolução mínima com 199 simulações: 0,005.
# SES é descritivo: |SES| > 2 NÃO garante p < 0,05; não supomos normalidade.
teste_nulo <- data.frame(NODF = nodf_observado, media_nula = mean(nodf_nulo),
                         sd_nulo = sd_nulo, SES = ses, p_superior = p_superior, B = B)
print(teste_nulo)
write.csv(teste_nulo, 'results/teste_nulo.csv', row.names = FALSE)
write.csv(data.frame(NODF = nodf_nulo), 'results/distribuicao_nula.csv', row.names = FALSE)
grafico_nulo <- ggplot(data.frame(NODF = nodf_nulo), aes(NODF)) +
  geom_histogram(bins = 25, fill = '#56B4E9', colour = 'white') +
  geom_vline(xintercept = nodf_observado, colour = '#D55E00', linewidth = 1) +
  labs(x = 'NODF', y = 'Número de simulações', title = 'Aninhamento e expectativa nula',
       subtitle = 'Linha laranja: observado | Margens quantitativas fixas') +
  tema_aula()
print(grafico_nulo)
salvar_grafico(grafico_nulo, '07_modelo_nulo')
# DISCUTA: rejeitar H0 identifica o mecanismo ecológico? Não: outras explicações
# (inclusive amostragem) podem produzir desvio. Mudar as restrições muda a pergunta.

# 11. Perda de recursos e robustez topológica | 25 min ----
# Simulação na rede de dispersão. Perda de sementes consumidas não equivale
# automaticamente à extinção demográfica de aves ou morcegos.
md <- matriz_ativa(matrizes$dispersao)
ordem_grau <- order(rowSums(md > 0), decreasing = TRUE, rownames(md))
alvo <- curva_perda(md, ordem_grau)
set.seed(33)
repeticoes <- replicate(199, curva_perda(md, sample(seq_len(nrow(md))))$sobreviventes)
curvas <- data.frame(removidos = alvo$removidos,
                     media = rowMeans(repeticoes),
                     inferior = apply(repeticoes, 1, quantile, probs = 0.025),
                     superior = apply(repeticoes, 1, quantile, probs = 0.975),
                     alvo = alvo$sobreviventes)
areas_aleatorias <- apply(repeticoes, 2, function(y) {
  area_curva(data.frame(removidos = alvo$removidos, sobreviventes = y))
})
robustez <- data.frame(estrategia = c('Maior grau inicial', 'Aleatória: média'),
                       area = c(area_curva(alvo), mean(areas_aleatorias)))
print(robustez)
write.csv(robustez, 'results/robustez.csv', row.names = FALSE)
write.csv(curvas, 'results/curvas_perda.csv', row.names = FALSE)
grafico_perda <- ggplot(curvas, aes(removidos)) +
  geom_ribbon(aes(ymin = inferior, ymax = superior), fill = '#56B4E9', alpha = 0.25) +
  geom_line(aes(y = media, colour = 'Aleatória'), linewidth = 1) +
  geom_line(aes(y = alvo, colour = 'Maior grau inicial'), linewidth = 1) +
  scale_colour_manual(values = c('Aleatória' = '#0072B2', 'Maior grau inicial' = '#D55E00')) +
  labs(x = 'Proporção de plantas removidas', y = 'Fração de parceiros com recurso',
       colour = 'Ordem de remoção', title = 'O efeito da perda depende de quais nós saem',
       subtitle = 'Faixa: 95% das simulações aleatórias; não é intervalo de confiança de campo') +
  tema_aula()
print(grafico_perda)
salvar_grafico(grafico_perda, '08_perda_parceiros')
# Área maior = retenção de parceiros por mais tempo sob ESTE cenário.
# Não medir resiliência (recuperação temporal) com esta simulação estática.
# Exercício 5: remova primeiro plantas de menor grau; compare as curvas.

# 12. Miniprojeto em duplas | 50 min + 15 min de intervalo na aula 2 ----
# Escolha: (a) polinização, (b) dispersão, (c) herbivoria ou (d) cacau.
# 1. Formule uma pergunta e uma previsão antes de calcular índices.
# 2. Explique o que são nós, arestas, zeros e pesos; cite o protocolo da planilha.
# 3. Selecione duas métricas adequadas e uma visualização de igraph.
# 4. Faça uma análise de sensibilidade (pesos/binário; remoção; separação de método).
# 5. Entregue script comentado, figura, tabela e interpretação de até 300 palavras.
# 6. Apresente em 5 minutos: pergunta -> evidência -> conclusão -> limitação.
# Para inferência com modelo nulo, declare as restrições e aumente B.
# Critérios: pergunta 2 pts; dados/reprodutibilidade 2; método 2; figura 2;
# interpretação e limites 2. Não premiar quantidade de métricas sem justificativa.

# 13. Exportação e registro de versões ----
write.csv(nos_aula, 'results/nos_didaticos.csv', row.names = FALSE)
saveRDS(list(didatica = m_aula, anexos = matrizes, cacau = cacau_matrizes),
        'results/matrizes_analisadas.rds')
write.csv(data.frame(NODF = nodf_observado, H2 = as.numeric(h2), Q_bipartido = Q_bipartido),
          'results/indices_avancados.csv', row.names = FALSE)
capture.output(sessionInfo(), file = 'results/sessionInfo.txt')
message('Roteiro concluído. Figuras em figures/ e tabelas em results/.')
