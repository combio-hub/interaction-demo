# MÉTRICAS E MODELOS NULOS | Polinização ----
# 1. Pacotes, entrada e parâmetros ----
# install.packages(c("readxl", "igraph", "vegan", "bipartite", "ggplot2"))
library(igraph)
library(ggplot2)
# Usar pol da sessão, se existir; caso contrário, ler a matriz do anexo original.
if (!exists("pol", inherits = FALSE)) {
  dados = as.data.frame(readxl::read_xls("polinizacao1.xls", sheet = 2, range = "A1:CY13"), check.names = FALSE)
  rownames(dados) = dados[, 1]
  pol = as.matrix(dados[, -1])
}
# Para uma demonstração curta: options(redes.B = 199L), antes de executar.
# options(redes.B = NULL) restaura o padrão de 999 simulações por modelo.
B = getOption("redes.B", 999L)
n_inicios = getOption("redes.inicios", 10L)
alternativa = "bilateral"
stopifnot(B >= 19, B == as.integer(B), n_inicios >= 1, n_inicios == as.integer(n_inicios))
for (pasta in c("results", "figures")) dir.create(pasta, showWarnings = FALSE)
# 2. Preparar a matriz quantitativa ----
matriz = as.matrix(pol)
stopifnot(is.numeric(matriz), all(is.finite(matriz)), all(matriz >= 0), all(matriz == round(matriz)))
excluidos = c(plantas = sum(rowSums(matriz) == 0), visitantes = sum(colSums(matriz) == 0))
matriz = matriz[rowSums(matriz) > 0, colSums(matriz) > 0, drop = FALSE]
stopifnot(nrow(matriz) >= 2, ncol(matriz) >= 2)
n_ligacoes = sum(matriz > 0)
# Não excluir nós das simulações depois da geração; conferir dimensões e margens.
# Contagens representam eventos; não multiplicar proporções para inventar contagens.
# 3. Funções das métricas ----
melhor_modularidade = function(m, semente) {
  g = graph_from_biadjacency_matrix(m, directed = FALSE, weighted = TRUE)
  set.seed(semente)
  melhor_q = -Inf
  melhor_grupo = NULL
  # Mesmo esforço de otimização no observado e em cada matriz nula.
  for (inicio in seq_len(n_inicios)) {
    grupo = membership(cluster_louvain(g, weights = E(g)$weight))
    q = modularity(g, grupo, weights = E(g)$weight)
    if (q > melhor_q) {
      melhor_q = q
      melhor_grupo = grupo
    }
  }
  list(Q = melhor_q, grupo = melhor_grupo)
}
calcular_metricas = function(m, semente) {
  b = 1L * (m > 0)
  modulos = melhor_modularidade(m, semente)
  c(conectancia = sum(b) / length(b),
    NODF = unname(vegan::nestednodf(b, order = TRUE, weighted = FALSE)$statistic["NODF"]),
    Q = modulos$Q, ligacoes_por_especie = sum(b) / sum(dim(b)),
    H2 = as.numeric(bipartite::networklevel(m, index = "H2", H2_integer = TRUE)))
}
# C = L/(P×V); ligações/espécie = L/(P+V), diferente do grau médio 2L/(P+V).
# NODF é binário (0–100); H2' usa frequências (0–1).
# Q é modularidade ponderada geral do igraph, não Q específico bipartido.
# 4. Métricas observadas e composição dos módulos ----
observado = calcular_metricas(matriz, semente = 123)
modulos_obs = melhor_modularidade(matriz, semente = 123)
nomes = c(conectancia = "Conectância", NODF = "Aninhamento (NODF)", Q = "Modularidade ponderada (Q)",
          ligacoes_por_especie = "Ligações por espécie (L/S)", H2 = "Especialização (H2')")
metricas = data.frame(metrica = unname(nomes[names(observado)]), valor = unname(observado))
print(metricas, row.names = FALSE, digits = 4)
tabela_modulos = data.frame(especie = c(rownames(matriz), colnames(matriz)),
  guilda = c(rep("Plantas", nrow(matriz)), rep("Visitantes florais", ncol(matriz))),
  modulo = as.integer(modulos_obs$grupo))
# 5. Hipóteses dos três modelos ----
# shuffle.web: redistribui valores, mantendo dimensões, L, peso total e conjunto de pesos.
# Não mantém os totais por espécie: referência menos restritiva para NODF, Q e H2'.
# swap.web: mantém dimensões, L e totais de linhas/colunas; não fixa graus por espécie.
# Pergunta se NODF, Q e H2' diferem apesar de mesmos totais por espécie e mesmo L.
# r2dtable: mantém dimensões e totais de linhas/colunas, mas permite variar L.
# Pergunta se há mais/menos pares ocupados sob associação aleatória com essas margens.
# Os dois primeiros fixam C e L/S: nessas linhas, SES e p serão NA.
# C e L/S são proporcionais para dimensões fixas: não são evidências independentes.
# Todos os pares são permitidos: zeros estruturais conhecidos não são impostos.
# A implementação de shuffle.web evita margens vazias; não é permutação irrestrita.
# swap.web pode favorecer pesos extremos e elevar H2' esperado (ver documentação).
# Os p-valores descrevem esses algoritmos; não garantem amostragem uniforme do
# espaço de matrizes nem identificam mecanismos causais de interação.
# 6. Gerar as redes nulas ----
message("Gerando ", B, " matrizes por modelo...")
set.seed(1101)
nulas_shuffle = bipartite::shuffle.web(web = matriz, N = B, legacy = TRUE)
set.seed(1102)
nulas_swap = bipartite::swap.web(N = B, web = matriz, verbose = FALSE)
set.seed(1103)
nulas_r2d = stats::r2dtable(n = B, r = rowSums(matriz), c = colSums(matriz))
# Cada rede é gerada pela função solicitada, sem substituir o algoritmo.
# 7. Conferir restrições antes de calcular os índices ----
conferir_nula = function(m, modelo) {
  stopifnot(identical(dim(m), dim(matriz)), all(is.finite(m)), all(m >= 0),
            all(m == round(m)), sum(m) == sum(matriz), all(rowSums(m) > 0), all(colSums(m) > 0))
  if (modelo %in% c("shuffle.web", "swap.web")) stopifnot(sum(m > 0) == n_ligacoes)
  if (modelo %in% c("swap.web", "r2dtable")) {
    stopifnot(all(rowSums(m) == rowSums(matriz)), all(colSums(m) == colSums(matriz)))
  }
  if (modelo == "shuffle.web") stopifnot(all(sort(as.numeric(m)) == sort(as.numeric(matriz))))
  TRUE
}
stopifnot(all(vapply(nulas_shuffle, conferir_nula, logical(1), modelo = "shuffle.web")),
          all(vapply(nulas_swap, conferir_nula, logical(1), modelo = "swap.web")),
          all(vapply(nulas_r2d, conferir_nula, logical(1), modelo = "r2dtable")))
# 8. Calcular distribuições nulas ----
calcular_serie = function(lista, modelo, semente_base) {
  saida = matrix(NA_real_, nrow = length(lista), ncol = length(observado), dimnames = list(NULL, names(observado)))
  for (i in seq_along(lista)) {
    saida[i, ] = calcular_metricas(lista[[i]], semente = semente_base + i)
    if (i %% 100 == 0) message(modelo, ": ", i, "/", length(lista))
  }
  saida
}
sim_shuffle = calcular_serie(nulas_shuffle, "shuffle.web", 20000)
sim_swap = calcular_serie(nulas_swap, "swap.web", 40000)
# r2dtable é usado somente para C e L/S; ambos dependem do mesmo L.
L_r2d = vapply(nulas_r2d, function(m) sum(m > 0), numeric(1))
sim_r2d = cbind(conectancia = L_r2d / length(matriz), ligacoes_por_especie = L_r2d / sum(dim(matriz)))
# 9. SES e probabilidades empíricas ----
# SES = (observado - média nula) / desvio-padrão nulo.
# As duas caudas incluem empates e correção +1 para evitar p = 0.
# Bilateral = min(1, 2 × menor cauda), convenção conservadora para dados discretos.
# Com B = 999, o mínimo unilateral é 0,001; o mínimo bilateral é 0,002.
# O intervalo 2,5%–97,5% descreve a distribuição nula; não é IC do observado.
resumir = function(sim, modelo) {
  linhas = lapply(colnames(sim), function(metrica) {
    x = sim[, metrica]
    obs = observado[[metrica]]
    stopifnot(all(is.finite(x)))
    fixa = modelo != "r2dtable" && metrica %in% c("conectancia", "ligacoes_por_especie")
    desvio = sd(x)
    variavel = !fixa && desvio > 1e-12
    tolerancia = 1e-10 * max(1, abs(obs))
    p_menor = if (variavel) (1 + sum(x <= obs + tolerancia)) / (length(x) + 1) else NA_real_
    p_maior = if (variavel) (1 + sum(x >= obs - tolerancia)) / (length(x) + 1) else NA_real_
    data.frame(modelo = modelo, codigo = metrica, metrica = nomes[[metrica]],
      observado = obs, media_nula = mean(x), dp_nulo = if (fixa) 0 else desvio,
      q025 = unname(quantile(x, 0.025)), q975 = unname(quantile(x, 0.975)),
      SES = if (variavel) (obs - mean(x)) / desvio else NA_real_,
      p_inferior = p_menor, p_superior = p_maior,
      p_bilateral = if (variavel) min(1, 2 * min(p_menor, p_maior)) else NA_real_, B = length(x),
      status = if (fixa) "Fixada pelo modelo" else if (!variavel) "Sem variação simulada; investigar" else "Comparação calculada")
  })
  do.call(rbind, linhas)
}
resultados = rbind(resumir(sim_shuffle, "shuffle.web"), resumir(sim_swap, "swap.web"), resumir(sim_r2d, "r2dtable"))
# Sete comparações: 3 índices × 2 modelos + conectância sob r2dtable.
# L/S não entra uma segunda vez no ajuste: é o mesmo teste que conectância.
resultados$p_holm = NA_real_
selecionados = is.finite(resultados$p_bilateral) & resultados$codigo != "ligacoes_por_especie"
resultados$p_holm[selecionados] = p.adjust(resultados$p_bilateral[selecionados], method = "holm")
indice_c = which(resultados$modelo == "r2dtable" & resultados$codigo == "conectancia")
indice_ls = which(resultados$modelo == "r2dtable" & resultados$codigo == "ligacoes_por_especie")
resultados$p_holm[indice_ls] = resultados$p_holm[indice_c]
print(resultados[resultados$status == "Comparação calculada", c("modelo", "metrica", "observado", "media_nula", "SES", "p_bilateral", "p_holm", "status")], row.names = FALSE, digits = 4)
# Não escolher teste unilateral após observar o resultado nem substituir p por |SES| > 2.
# 10. Gráficos de comparação ----
empilhar = function(sim, modelo) {
  do.call(rbind, lapply(colnames(sim), function(codigo) {
    data.frame(modelo = modelo, codigo = codigo, metrica = nomes[[codigo]], valor = sim[, codigo], simulacao = seq_len(nrow(sim)))
  }))
}
distribuicoes = rbind(empilhar(sim_shuffle, "shuffle.web"), empilhar(sim_swap, "swap.web"), empilhar(sim_r2d, "r2dtable"))
tema_nulo = theme_minimal(base_family = "sans") +
  theme(axis.text = element_text(size = 12, color = "black"), axis.title = element_text(size = 14, face = "bold"),
        strip.text = element_text(size = 12, face = "bold"), panel.grid.minor = element_blank(),
        plot.title = element_text(face = "bold"), legend.position = "right")
cores_modelos = c("shuffle.web" = "#0072B2", "swap.web" = "#009E73", "r2dtable" = "#56B4E9")
graficos = list()
for (modelo in names(cores_modelos)) {
  codigos = if (modelo == "r2dtable") c("conectancia", "ligacoes_por_especie") else c("NODF", "Q", "H2")
  dados_plot = distribuicoes[distribuicoes$modelo == modelo & distribuicoes$codigo %in% codigos, ]
  referencia = resultados[resultados$modelo == modelo & resultados$codigo %in% codigos, ]
  grafico = ggplot(dados_plot, aes(x = valor)) +
    geom_histogram(bins = 25, fill = cores_modelos[[modelo]], color = "white") +
    geom_vline(data = referencia, aes(xintercept = observado), color = "#D55E00", linewidth = 0.9) +
    facet_wrap(~metrica, scales = "free", ncol = if (modelo == "r2dtable") 2 else 3) +
    labs(x = "Valor da métrica", y = "Número de simulações", title = paste("Modelo nulo:", modelo),
      subtitle = "Linha laranja: observado | Histogramas: redes aleatorizadas",
      caption = if (modelo == "r2dtable") "Conectância e L/S são proporcionais: os painéis representam a mesma evidência." else "Comparações condicionais ao algoritmo e às restrições; não indicam mecanismos causais.") +
    tema_nulo
  graficos[[modelo]] = grafico
  print(grafico)
  ggsave(file.path("figures", paste0("modelos_nulos_", modelo, ".png")), plot = grafico,
         width = 13, height = 5.5, units = "in", dpi = 180, bg = "white")
}
# 11. Exportar resultados e registrar a execução ----
write.csv2(metricas, "results/metricas_polinizacao.csv", row.names = FALSE, fileEncoding = "UTF-8")
write.csv2(tabela_modulos, "results/modulos_polinizacao_igraph.csv", row.names = FALSE, fileEncoding = "UTF-8")
write.csv2(resultados, "results/testes_modelos_nulos.csv", row.names = FALSE, fileEncoding = "UTF-8")
write.csv2(distribuicoes, "results/distribuicoes_modelos_nulos.csv", row.names = FALSE, fileEncoding = "UTF-8")
saveRDS(list(matriz = matriz, shuffle = nulas_shuffle, swap = nulas_swap, r2dtable = nulas_r2d,
             B = B, n_inicios = n_inicios, alternativa = alternativa, excluidos = excluidos,
             resultados = resultados), "results/modelos_nulos_completos.rds")
capture.output(sessionInfo(), file = "results/sessionInfo_modelos_nulos.txt")
# Checar índices fixados e equivalência dos testes de C e L/S.
stopifnot(all(abs(sim_shuffle[, "conectancia"] - observado[["conectancia"]]) < 1e-12),
          all(abs(sim_swap[, "ligacoes_por_especie"] - observado[["ligacoes_por_especie"]]) < 1e-12),
          isTRUE(all.equal(resultados$p_bilateral[indice_c], resultados$p_bilateral[indice_ls])),
          isTRUE(all.equal(resultados$SES[indice_c], resultados$SES[indice_ls], tolerance = 1e-8)))
message("Concluído: ", B, " matrizes por modelo. Consulte results/testes_modelos_nulos.csv.")
# Fontes: https://search.r-project.org/CRAN/refmans/bipartite/html/shuffle.web.html
# https://search.r-project.org/CRAN/refmans/bipartite/html/swap.web.html
# https://stat.ethz.ch/R-manual/R-devel/library/stats/html/r2dtable.html
