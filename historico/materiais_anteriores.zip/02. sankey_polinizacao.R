# 1. Pacotes e dados originais ----
library(readxl)
library(ggplot2)
library(ggsankey)
pol = read_xls('polinizacao1.xls', sheet = 2, range = 'A1:CY13', col_names = TRUE)
pol = data.frame(pol, check.names = FALSE)
rownames(pol) = pol[, 1]
pol = as.matrix(pol[, -1])
pos = which(pol > 0, arr.ind = TRUE)
interacoes = data.frame(Plantas = rownames(pol)[pos[, 1]], Visitantes = colnames(pol)[pos[, 2]], frequencia = as.numeric(pol[pos]))
# 2. Preparar a rede completa ----
plot_data = make_long(interacoes, Plantas, Visitantes, value = frequencia)
plot_data$guilda = factor(plot_data$x, levels = c('Plantas', 'Visitantes'))
min_rotulo = 10
cores = c('Plantas' = '#008000', 'Visitantes' = '#D55E00')
# 3. Desenhar primeiro os fluxos e os retângulos, sem texto ----
# Sem bordas: contornos brancos encobrem nós/fluxos com poucos registros.
# space controla apenas a separação entre nós; os pesos continuam originais.
rede_base = ggplot(plot_data, aes(x = x, next_x = next_x, node = node, next_node = next_node, value = value, fill = guilda)) +
  geom_sankey(flow.alpha = 0.55, flow.color = NA, node.color = NA, width = 0.12, space = 2) +
  scale_fill_manual(values = cores, labels = c('Plantas', 'Visitantes florais')) +
  scale_x_discrete(labels = c('Plantas', 'Visitantes florais'), expand = expansion(add = c(0.65, 0.65))) +
  labs(x = NULL, y = NULL, fill = 'Guilda', title = 'Rede planta–visitante floral',
       subtitle = 'Largura das faixas proporcional à frequência registrada',
       caption = paste0('Matriz completa | Nomes para nós com ≥ ', min_rotulo, ' registros | Fonte: polinizacao1.xls')) +
  theme_minimal(base_family = 'sans') +
  theme(panel.grid = element_blank(), axis.text.y = element_blank(), axis.ticks = element_blank(),
        axis.text.x = element_text(size = 14, color = 'black', face = 'bold'),
        legend.position = 'right', legend.title = element_text(size = 12, face = 'bold'),
        legend.text = element_text(size = 10), legend.background = element_blank(),
        plot.title = element_text(size = 16, face = 'bold'), plot.subtitle = element_text(size = 12),
        plot.caption = element_text(size = 10, hjust = 0), plot.margin = margin(15, 20, 15, 20))
# 4. Usar os centros dos retângulos efetivamente desenhados ----
# O texto não recalcula o layout: cada nome é vinculado ao próprio retângulo.
construido = ggplot_build(rede_base)
camada_nos = which(vapply(rede_base$layers, function(z) inherits(z$geom, 'GeomRect'), logical(1)))
stopifnot(length(camada_nos) == 1)
nos = construido$data[[camada_nos]]
stopifnot(all(c('node', 'freq', 'xmin', 'xmax', 'ymin', 'ymax') %in% names(nos)))
rotulos = nos[nos$freq >= min_rotulo, ]
rotulos$y_texto = (rotulos$ymin + rotulos$ymax) / 2
# FALSE: nomes nas pontas, alinhados ao centro vertical do nó.
# TRUE: nomes sobre o centro do próprio retângulo, nos dois eixos.
sobre_nos = FALSE
if (sobre_nos) {
  rotulos$x_texto = (rotulos$xmin + rotulos$xmax) / 2
  rotulos$alinhamento = 0.5
} else {
  esquerda = rotulos$x == min(nos$x)
  rotulos$x_texto = ifelse(esquerda, rotulos$xmin - 0.02, rotulos$xmax + 0.02)
  rotulos$alinhamento = ifelse(esquerda, 1, 0)
}
rede_plot = rede_base +
  geom_text(data = rotulos, aes(x = x_texto, y = y_texto, label = node, hjust = alinhamento),
            inherit.aes = FALSE, vjust = 0.5, family = 'sans', size = 3, color = 'black')
print(rede_plot)
# 5. Exportar sem sobrescrever a figura anterior ----
dir.create('figures', showWarnings = FALSE)
ggsave('figures/rede_polinizacao_sankey_alinhado.png', plot = rede_plot, width = 14, height = 10, units = 'in', dpi = 150, bg = 'white')
ggsave('figures/rede_polinizacao_sankey_alinhado.tiff', plot = rede_plot, width = 14, height = 10, units = 'in', dpi = 600, compression = 'lzw', bg = 'white')
