# Redes de interações ecológicas | UFPA ----
# Abra interactions_ufpa.Rproj. Execute este arquivo antes da primeira aula.
# Internet é necessária apenas para instalar pacotes ausentes.
# Os arquivos Excel originais são apenas lidos; nunca são sobrescritos.

if (!file.exists('interactions_ufpa.Rproj')) {
  stop('Abra interactions_ufpa.Rproj para trabalhar na pasta do projeto.')
}

# Biblioteca local permite instalar sem alterar a instalação principal do R.
dir.create('biblioteca_R', showWarnings = FALSE)
versao_r <- paste(R.version$major, strsplit(R.version$minor, '.', fixed = TRUE)[[1]][1], sep = '.')
lib_usuario <- file.path(Sys.getenv('USERPROFILE'), 'AppData', 'Local',
                         'R', 'win-library', versao_r)
.libPaths(c('biblioteca_R', lib_usuario, .libPaths()))
pacotes <- c('igraph', 'readxl', 'ggplot2', 'vegan', 'bipartite')
faltantes <- pacotes[!vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltantes) > 0) {
  install.packages(faltantes, lib = 'biblioteca_R', repos = 'https://cloud.r-project.org')
}
stopifnot(all(vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)))
message('Preparação concluída. Abra 01. aula_pratica.R e execute por seções.')
