# Importação auditável dos anexos ----
# Intervalos foram conferidos nas planilhas originais em 01/11/2026.
# Alterações no formato dos anexos exigem nova conferência dos intervalos.
matrizes <- list(
  polinizacao = ler_matriz('polinizacao1.xls', 'originai', 'A1:CY13'),
  dispersao = ler_matriz('dispersao1.xls', 'dados', 'A1:S88', distinguir_duplicados = TRUE),
  herbivoria = ler_matriz('herbivoria.xls', 'original(marathon)', 'A1:Y55')
)
# Polinização: exclui legendas e linhas vazias após a linha 13.
# Dispersão: somente bloco quantitativo A:S; X:AP repete a versão binária.
# Herbivoria: somente A:Y; as colunas seguintes não são espécies.
# Dispersão tem duas linhas chamadas Araceae 1 (linhas Excel 6 e 7).
# Mantemos unidades distintas com sufixos de linha, sem inventar identificação.
# Confirmar no material de origem se são o mesmo táxon antes de inferir riqueza.
# Sensibilidade: somar essas linhas representa a hipótese alternativa de um só táxon.
nomes_originais <- read.csv('results/dispersao_identidades.csv')$nome_original
dispersao_agregada <- rowsum(matrizes$dispersao, nomes_originais, reorder = FALSE)
sensibilidade_nomes <- rbind(linhas_separadas = metricas_rede(matrizes$dispersao),
                             nomes_agregados = metricas_rede(dispersao_agregada))
write.csv(sensibilidade_nomes, 'results/dispersao_sensibilidade_nomes.csv')

inventario <- data.frame(
  arquivo = c('polinizacao1.xls', 'dispersao1.xls', 'herbivoria.xls',
              'visitantes_cacau_base.xlsx', 'ectoparasitismo.xlsx'),
  uso = c('originai!A1:CY13; visitantes florais; contagens',
          'dados!A1:S88; sementes em amostras fecais; contagens por par',
          'original(marathon)!A1:Y55; presença/ausência',
          'Planilha1; genótipo x grupo; separar sistema e método',
          'Não analisado: arquivo de 165 bytes não abre como XLSX'))
write.csv(inventario, 'results/inventario_dados.csv', row.names = FALSE, fileEncoding = 'UTF-8')

cacau <- as.data.frame(readxl::read_excel('visitantes_cacau_base.xlsx'))
grupos_cacau <- c('Microdip', 'Aphididae', 'Formicidae', 'Hemiptera',
                  'Cicadellidae', 'Thysanoptera', 'Outros_Insetos', 'Outros_Artropodes')
stopifnot(all(c('Municipio', 'Sistema', 'Genotipo', 'Metodo_Coleta', 'Data',
                grupos_cacau) %in% names(cacau)), !anyNA(cacau))
stopifnot(all(vapply(cacau[grupos_cacau], is.numeric, logical(1))),
          all(as.matrix(cacau[grupos_cacau]) >= 0))
# Datas misturam texto mês/dia/ano e números seriais do Excel.
data_texto <- as.character(cacau$Data)
serial <- grepl('^[0-9]+$', data_texto)
cacau$data_padrao <- as.Date(rep(NA_character_, nrow(cacau)))
cacau$data_padrao[serial] <- as.Date(as.numeric(data_texto[serial]), origin = '1899-12-30')
cacau$data_padrao[!serial] <- as.Date(data_texto[!serial], format = '%m/%d/%Y')
stopifnot(!anyNA(cacau$data_padrao))
cacau$registro <- 1L
esforco <- aggregate(registro ~ Municipio + Sistema + Metodo_Coleta + Genotipo,
                     cacau, sum)
write.csv(esforco, 'results/cacau_numero_registros.csv', row.names = FALSE)
write.csv(cacau, 'results/cacau_dados_conferidos.csv', row.names = FALSE, fileEncoding = 'UTF-8')

# Não assumimos que uma linha corresponde a uma unidade amostral independente.
# Número igual de registros não garante igual número de flores/tempo de coleta.
cacau_matrizes <- list()
for (sistema in unique(cacau$Sistema)) {
  for (metodo in unique(cacau$Metodo_Coleta)) {
    sub <- cacau[cacau$Sistema == sistema & cacau$Metodo_Coleta == metodo, ]
    tab <- aggregate(sub[grupos_cacau], list(Genotipo = sub$Genotipo), sum)
    m <- as.matrix(tab[, -1])
    rownames(m) <- tab$Genotipo
    validar_matriz(m)
    cacau_matrizes[[paste(sistema, metodo, sep = '_')]] <- m
  }
}
for (nome in names(matrizes)) {
  write.csv(matrizes[[nome]], file.path('data', paste0(nome, '_matriz.csv')))
}
for (nome in names(cacau_matrizes)) {
  write.csv(cacau_matrizes[[nome]], file.path('data', paste0('cacau_', nome, '.csv')))
}
