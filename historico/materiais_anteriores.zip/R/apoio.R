# Funções de apoio ----
# As fórmulas introdutórias são mostradas diretamente em 01. aula_pratica.R.
# Este arquivo concentra importação, validação e tarefas repetidas.

validar_matriz <- function(m) {
  stopifnot(is.matrix(m), is.numeric(m), all(is.finite(m)), all(m >= 0),
            nrow(m) > 0, ncol(m) > 0, !is.null(rownames(m)),
            !is.null(colnames(m)), !anyDuplicated(rownames(m)),
            !anyDuplicated(colnames(m)), all(nzchar(rownames(m))),
            all(nzchar(colnames(m))))
  invisible(m)
}

ler_matriz <- function(arquivo, aba, intervalo, distinguir_duplicados = FALSE) {
  dados <- readxl::read_excel(arquivo, sheet = aba, range = intervalo,
                             .name_repair = 'minimal')
  # Primeira coluna: identidade do recurso; demais: valores por parceiro.
  # NA não é transformado em zero: ausência de informação não é ausência de ligação.
  m <- as.matrix(as.data.frame(dados[, -1]))
  rownames(m) <- trimws(dados[[1]])
  colnames(m) <- trimws(names(dados)[-1])
  if (distinguir_duplicados) {
    repetido <- duplicated(rownames(m)) | duplicated(rownames(m), fromLast = TRUE)
    mapa <- data.frame(linha_excel = seq_len(nrow(m)) + 1,
                       nome_original = rownames(m), nome_analise = rownames(m))
    mapa$nome_analise[repetido] <- paste0(mapa$nome_original[repetido],
      ' [linha ', mapa$linha_excel[repetido], ']')
    rownames(m) <- mapa$nome_analise
    write.csv(mapa, 'results/dispersao_identidades.csv', row.names = FALSE)
  }
  validar_matriz(m)
  m
}

rede_bipartida <- function(m, grupos = c('Recurso', 'Parceiro')) {
  validar_matriz(m)
  rotulos <- c(rownames(m), colnames(m))
  # Prefixos evitam confundir nós de guildas diferentes com o mesmo nome.
  rownames(m) <- paste0('R:', rownames(m))
  colnames(m) <- paste0('C:', colnames(m))
  g <- igraph::graph_from_biadjacency_matrix(m, directed = FALSE, weighted = TRUE)
  igraph::V(g)$label <- rotulos
  igraph::V(g)$grupo <- ifelse(igraph::V(g)$type, grupos[2], grupos[1])
  g
}

metricas_rede <- function(m) {
  g <- rede_bipartida(m)
  data.frame(recursos = nrow(m), parceiros = ncol(m), S = igraph::vcount(g),
             L = sum(m > 0), total_pesos = sum(m),
             conectancia = sum(m > 0) / length(m),
             ligacoes_por_no = sum(m > 0) / igraph::vcount(g),
             grau_medio = mean(igraph::degree(g)),
             componentes = igraph::components(g)$no,
             isolados = sum(igraph::degree(g) == 0))
}

metricas_nos <- function(g) {
  data.frame(id = igraph::V(g)$name, nome = igraph::V(g)$label,
             grupo = igraph::V(g)$grupo, grau = igraph::degree(g),
             forca = igraph::strength(g),
             intermediacao = igraph::betweenness(g, weights = NA, normalized = TRUE),
             harmonica = igraph::harmonic_centrality(g, weights = NA, normalized = TRUE),
             row.names = NULL)
}

desenhar_rede <- function(g, titulo, rotulos = TRUE, cores = NULL) {
  # Layout calculado pelo igraph; posições não representam distância geográfica.
  xy <- igraph::layout_as_bipartite(g)
  xy <- xy[, c(2, 1)]
  if (is.null(cores)) cores <- ifelse(igraph::V(g)$type, '#D55E00', '#0072B2')
  igraph::plot.igraph(g, layout = xy, main = titulo,
    vertex.color = cores, vertex.frame.color = 'white',
    vertex.size = 4 + 9 * sqrt(igraph::degree(g) / max(1, igraph::degree(g))),
    vertex.label = if (rotulos) igraph::V(g)$label else NA,
    vertex.label.cex = 0.75, vertex.label.color = 'black', vertex.label.family = 'sans',
    vertex.label.dist = 3, vertex.label.degree = ifelse(igraph::V(g)$type, pi, 0),
    edge.color = grDevices::adjustcolor('#576574', alpha.f = 0.35),
    edge.width = 0.4 + 3 * sqrt(igraph::E(g)$weight / max(igraph::E(g)$weight)),
    margin = c(0.15, 0.20, 0.15, 0.20))
  legend('topleft', legend = unique(igraph::V(g)$grupo),
         col = c('#0072B2', '#D55E00'), pch = 16, bty = 'n', cex = 0.8)
  mtext('Tamanho: grau | Espessura: peso (escala de raiz quadrada)', side = 1, cex = 0.8)
}

exportar_rede <- function(g, nome, titulo, rotulos = TRUE) {
  png(file.path('figures', paste0(nome, '.png')), width = 2000, height = 1400, res = 180)
  on.exit(dev.off())
  par(family = 'sans', mar = c(2, 1, 3, 1))
  desenhar_rede(g, titulo, rotulos)
}

tema_aula <- function() {
  ggplot2::theme_minimal(base_family = 'sans') +
    ggplot2::theme(axis.text = ggplot2::element_text(size = 12, colour = 'black'),
      axis.title = ggplot2::element_text(size = 14, face = 'bold'),
      legend.title = ggplot2::element_text(size = 12, face = 'bold'),
      legend.text = ggplot2::element_text(size = 10),
      legend.position = 'right', legend.background = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      plot.title = ggplot2::element_text(face = 'bold'))
}

salvar_grafico <- function(p, nome, largura = 9, altura = 6) {
  ggplot2::ggsave(file.path('figures', paste0(nome, '.png')), plot = p,
                 width = largura, height = altura, units = 'in', dpi = 180, bg = 'white')
}

matriz_ativa <- function(m) m[rowSums(m) > 0, colSums(m) > 0, drop = FALSE]

nodf <- function(m) {
  # NODF binário total (linhas e colunas), de 0 a 100; ordenar por grau.
  unname(vegan::nestednodf(1L * (m > 0), order = TRUE, weighted = FALSE)$statistic['NODF'])
}

curva_perda <- function(m, ordem) {
  # Remove recursos; parceiros sem nenhum recurso remanescente são considerados perdidos.
  # Não há religação nem dinâmica populacional. Ordem fixa, sem recalcular graus.
  stopifnot(setequal(ordem, seq_len(nrow(m))), !anyDuplicated(ordem))
  ativos <- colSums(m) > 0
  if (!any(ativos)) stop('Não há parceiros ativos para simular.')
  m <- m[, ativos, drop = FALSE]
  sobreviventes <- numeric(nrow(m) + 1)
  sobreviventes[1] <- 1
  for (i in seq_len(nrow(m))) {
    restante <- m[-ordem[seq_len(i)], , drop = FALSE]
    sobreviventes[i + 1] <- mean(colSums(restante) > 0)
  }
  data.frame(removidos = (0:nrow(m)) / nrow(m), sobreviventes = sobreviventes)
}

area_curva <- function(curva) {
  # Integração trapezoidal; explicitar a convenção ao comparar outros programas.
  y <- curva$sobreviventes
  sum(diff(curva$removidos) * (head(y, -1) + tail(y, -1)) / 2)
}
