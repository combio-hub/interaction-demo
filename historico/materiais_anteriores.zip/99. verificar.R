# Checagens do roteiro e de propriedades matemáticas ----
# Execute após 01. aula_pratica.R na mesma sessão.
stopifnot(exists('m_aula'), exists('matrizes'), exists('nulas'))
stopifnot(identical(m_aula, m_polinizacao[plantas_aula, ordem_visitantes[1:5], drop = FALSE]),
          all(igraph::degree(g_aula) == c(rowSums(m_aula > 0), colSums(m_aula > 0))),
          all(igraph::strength(g_aula) == c(rowSums(m_aula), colSums(m_aula))))

# Referências independentes: dimensões e somas conferidas nos blocos originais.
stopifnot(identical(dim(matrizes$polinizacao), c(12L, 102L)),
          identical(dim(matrizes$dispersao), c(87L, 18L)),
          identical(dim(matrizes$herbivoria), c(54L, 24L)),
          sum(matrizes$polinizacao) == 550,
          sum(matrizes$dispersao) == 1177,
          all(matrizes$herbivoria %in% c(0, 1)))

# A agregação de identidades deve preservar pesos, mas pode mudar ligações.
stopifnot(sum(dispersao_agregada) == sum(matrizes$dispersao),
          nrow(dispersao_agregada) == 86,
          nrow(cacau) == 120, length(cacau_matrizes) == 4,
          sum(vapply(cacau_matrizes, sum, numeric(1))) == sum(as.matrix(cacau[grupos_cacau])))
for (m_teste in c(matrizes, cacau_matrizes)) {
  g_teste <- rede_bipartida(m_teste)
  stopifnot(igraph::is_bipartite(g_teste),
            sum(igraph::degree(g_teste)) == 2 * sum(m_teste > 0),
            sum(igraph::E(g_teste)$weight) == sum(m_teste))
}
stopifnot(all(vapply(nulas, function(z) all(rowSums(z) == rowSums(m)) &&
                      all(colSums(z) == colSums(m)), logical(1))))

# Caso-limite: dois pares independentes -> perdas 1, 1/2, 0; área=1/2.
teste_perda <- curva_perda(diag(2), 1:2)
stopifnot(all(teste_perda$sobreviventes == c(1, 0.5, 0)), area_curva(teste_perda) == 0.5,
          all(diff(alvo$sobreviventes) <= 0), all(repeticoes[1, ] == 1),
          all(tail(repeticoes, 1) == 0))

# NODF total inclui pares empatados no denominador: matriz triangular 3x3=100.
triangular <- matrix(c(1,1,1, 1,1,0, 1,0,0), 3, byrow = TRUE)
stopifnot(abs(nodf(triangular) - 100) < 1e-8)

# Recalcular Q bipartido diretamente a partir da partição para conferir mapeamento.
mod_l <- tabela_modulos$modulo[match(paste0('R:', rownames(m)), tabela_modulos$id)]
mod_c <- tabela_modulos$modulo[match(paste0('C:', colnames(m)), tabela_modulos$id)]
esperado <- outer(rowSums(m), colSums(m)) / sum(m)
q_manual <- sum((m - esperado) * outer(mod_l, mod_c, '==')) / sum(m)
stopifnot(abs(q_manual - Q_bipartido) < 1e-8)
writeLines(c('VALIDAÇÃO CONCLUÍDA',
  'Fórmulas básicas; importação; totais; separação do cacau; margens dos modelos nulos;',
  'caso-limite de perdas; NODF triangular; Q bipartido recalculado: todos conferidos.'),
  'results/validacao.txt')
message('Todas as checagens passaram.')
