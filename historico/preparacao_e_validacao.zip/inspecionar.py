import sys,json
from pathlib import Path
sys.path.insert(0,'C:/Users/Lucas Colares/AppData/Local/Temp/codex_redes_xlrd')
import xlrd
out=[]
for name in ['polinizacao1.xls','dispersao1.xls','herbivoria.xls']:
    book=xlrd.open_workbook(name,formatting_info=True)
    for sheet in book.sheets():
        cells=[]
        for r in range(sheet.nrows):
            for c in range(sheet.ncols):
                cell=sheet.cell(r,c)
                if cell.ctype in [xlrd.XL_CELL_EMPTY,xlrd.XL_CELL_BLANK]: continue
                xf=book.xf_list[cell.xf_index]
                bg=xf.background
                rgb=book.colour_map.get(bg.pattern_colour_index) if bg.fill_pattern else None
                font=book.font_list[xf.font_index]
                color=lambda x: '#%02X%02X%02X'%x if x is not None else ''
                cells.append(dict(r=r+1,c=c+1,v=cell.value,fill=color(rgb),font=color(book.colour_map.get(font.colour_index))))
        out.append(dict(file=name,sheet=sheet.name,rows=sheet.nrows,cols=sheet.ncols,cells=cells))
        print(name,repr(sheet.name),sheet.nrows,sheet.ncols)
        print('TEXTOS:',json.dumps([c for c in cells if isinstance(c['v'],str)],ensure_ascii=False))
Path('.preparo/inspecao_planilhas.json').write_text(json.dumps(out,ensure_ascii=False),encoding='utf-8')
