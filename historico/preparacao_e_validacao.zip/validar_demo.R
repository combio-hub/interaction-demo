Sys.setlocale("LC_CTYPE", "Portuguese_Brazil.utf8")
source("00. setup.R", encoding = "UTF-8")
for (rede in c("polinizacao", "dispersao", "herbivoria")) {
  obj = readRDS(file.path("results", rede, "analise.rds"))
  m = obj$matriz
  if (obj$info$tipo == "contagem") {
    trace = trajetoria_swap(m)
    set.seed(5102)
    referencia = bipartite::swap.web(1, m, verbose = FALSE)[[1]]
    stopifnot(isTRUE(all.equal(unname(tail(trace$quadros, 1)[[1]]), unname(referencia))))
    message(rede, ": trajetória real idêntica à chamada sem instrumentação; ", length(trace$quadros), " estados.")
  }
  original = as.matrix(readxl::read_xls(obj$info$arquivo, sheet = obj$info$aba, range = obj$info$intervalo)[, -1])
  stopifnot(identical(dim(m), dim(original)), all(m == original))
  figura = desenhar_rede(m, obj$categorias, obj$info, obj$min_rotulo)
  pasta = file.path("figures", rede)
  ggsave(file.path(pasta, "rede.png"), plot = figura, width = 14, height = 10, units = "in", dpi = 180, bg = "white")
  ggsave(file.path(pasta, "rede.tiff"), plot = figura, width = 14, height = 10, units = "in", dpi = 600, compression = "lzw", bg = "white")
  message(rede, ": CSV idêntico às células originais; figura conferida com todos os nós e pares.")
}
