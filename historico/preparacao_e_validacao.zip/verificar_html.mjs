import {chromium} from 'playwright';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import fs from 'node:fs/promises';
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
const page=await browser.newPage({viewport:{width:1440,height:1150}});
const errors=[];
page.on('pageerror',e=>errors.push(String(e)));
const results=[];
try{
 for(const rede of ['polinizacao','dispersao','herbivoria']){
  await page.goto(pathToFileURL(path.resolve(`figures/${rede}/demonstracao_modelos_nulos.html`)).href);
  await page.waitForSelector('#observed circle');
  const count=await page.locator('#model option').count();
  for(let i=0;i<count;i++){
   await page.locator('#model').selectOption(String(i));
   await page.locator('#next').click();
   await page.locator('#position').evaluate(el=>{el.value=el.max;el.dispatchEvent(new Event('input',{bubbles:true}));});
   const ver=await page.evaluate(()=>{
    const m=modelo(),q=m.quadros[indice];
    return {modelo:m.nome,etapas:m.quadros.length,total:q.total,L:q.L,margens:q.linhas.every((v,i)=>v===dados.observado.linhas[i])&&q.colunas.every((v,i)=>v===dados.observado.colunas[i]),fim:indice===m.quadros.length-1};
   });
   if(!ver.margens||!ver.fim)throw Error('Falha de margens/controle');
   await page.locator('#view').selectOption('matrix');
   if(!(await page.locator('#random rect').count()))throw Error('Matriz vazia');
   await page.locator('#view').selectOption('graph');
   results.push({rede,...ver});
  }
  await page.screenshot({path:`.preparo/demo_${rede}.png`,fullPage:true});
  await page.locator('#reset').click();
  await page.locator('#speed').selectOption('90');
  await page.locator('#play').click();
  await page.waitForFunction(()=>indice>0);
  await page.locator('#play').click();
 }
 if(errors.length)throw Error(errors.join('\n'));
 console.log(JSON.stringify(results,null,2));
 await fs.writeFile('.preparo/verificacao_html.json',JSON.stringify(results,null,2));
}finally{await browser.close();}
