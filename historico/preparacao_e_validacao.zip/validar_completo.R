Sys.setlocale("LC_CTYPE", "Portuguese_Brazil.utf8")
texto = readLines("01. aula_pratica.R", encoding = "UTF-8")
for (rede_teste in c("polinizacao", "dispersao", "herbivoria")) {
  message("INICIANDO: ", rede_teste)
  codigo = sub('^rede = "polinizacao"$', paste0('rede = "', rede_teste, '"'), texto)
  codigo = sub("^B = 999$", "B = 999", codigo)
  source(textConnection(codigo), encoding = "UTF-8")
  stopifnot(all(testes$dp_nulo > 0), all(is.finite(testes$p_holm)), all(testes$status == "Comparação calculada"))
  stopifnot(isTRUE(all.equal(unname(observado), unname(medir_rede(matriz, n_inicios, 123)))))
  if (rede_teste == "herbivoria") stopifnot(setequal(testes$codigo, c("NODF", "Q")), all(testes$modelo == "quasiswap"))
  if (rede_teste == "dispersao") stopifnot(sum(categorias$grupo == "Aves") == 7, sum(categorias$grupo == "Morcegos") == 11)
  message("VALIDADO: ", rede_teste)
}
writeLines(deparse(body(bipartite::swap.web)), ".preparo/swap_implementacao.txt")

