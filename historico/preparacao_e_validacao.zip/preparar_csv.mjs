import fs from 'node:fs/promises';
import { Workbook } from '@oai/artifact-tool';
const fontes = JSON.parse(await fs.readFile('.preparo/inspecao_planilhas.json', 'utf8'));
const wb = Workbook.create();
const configuracoes = [
  {rede:'polinizacao',arquivo:'polinizacao1.xls',aba:'originai',nr:12,nc:102,tipo:'contagem',animal:'Visitantes florais',titulo:'Rede planta–visitante floral',unidade:'Indivíduos visitantes coletados',intervalo:'A1:CY13',referencia:'Barrett e Helenurm (1987)',nota:'Visitação não comprova polinização efetiva.'},
  {rede:'dispersao',arquivo:'dispersao1.xls',aba:'dados',nr:87,nc:18,tipo:'contagem',animal:'Frugívoros',titulo:'Rede planta–frugívoro',unidade:'Amostras fecais com sementes do táxon',intervalo:'A1:S88',referencia:'Gorchov et al. (1995)',nota:'Duas linhas Araceae 1 mantidas distintas; identidade taxonômica pendente. Uma amostra fecal pode conter mais de um táxon.'},
  {rede:'herbivoria',arquivo:'herbivoria.xls',aba:'original(marathon)',nr:54,nc:24,tipo:'binaria',animal:'Herbívoros',titulo:'Rede planta–herbívoro',unidade:'Presença ou ausência de consumo',intervalo:'A1:Y55',referencia:'Joern (1979)',nota:'Marathon; matriz binária sem frequência de consumo.'}
];
const limpar = x => String(x).trim().replace(/\s+/g,' ');
const letra = n => n > 26 ? letra(Math.floor((n-1)/26)) + letra((n-1)%26+1) : String.fromCharCode(64+n);
const csv = rows => rows.map(row => row.map(x => '"'+String(x ?? '').replaceAll('"','""')+'"').join(',')).join('\n')+'\n';
await fs.mkdir('data',{recursive:true});
let auditoria = [];
for (const cfg of configuracoes) {
  const fonte=fontes.find(x=>x.file===cfg.arquivo&&x.sheet===cfg.aba);
  const cells=new Map(fonte.cells.map(x=>[`${x.r},${x.c}`,x]));
  const cel=(r,c)=>cells.get(`${r},${c}`);
  const origLinhas=Array.from({length:cfg.nr},(_,i)=>cel(i+2,1).v);
  const contagem=new Map(origLinhas.map(x=>[limpar(x),origLinhas.filter(v=>limpar(v)===limpar(x)).length]));
  const linhas=origLinhas.map((x,i)=>contagem.get(limpar(x))>1?`${limpar(x)} [linha ${i+2}]`:limpar(x));
  const colunas=Array.from({length:cfg.nc},(_,i)=>limpar(cel(1,i+2).v));
  const valores=Array.from({length:cfg.nr},(_,r)=>Array.from({length:cfg.nc},(_,c)=>cel(r+2,c+2).v));
  if (valores.flat().some(x=>typeof x!=='number'||!Number.isInteger(x)||x<0)) throw Error('Célula inválida');
  const matriz=[['especie',...colunas],...valores.map((x,i)=>[linhas[i],...x])];
  const categorias=[['id','especie','guilda','grupo','cor','nome_original','cor_fonte_original','cor_fundo_original','celula_original','fonte_categoria','observacao']];
  for (let i=0;i<cfg.nr;i++) {
    const cell=cel(i+2,1);
    categorias.push([linhas[i],linhas[i],'Plantas','Plantas','#008000',cell.v,cell.font,cell.fill,`${cfg.aba}!A${i+2}`,'Eixo das linhas e cor dos nomes',contagem.get(limpar(cell.v))>1?'Identidade repetida; linhas preservadas como unidades distintas':'']);
  }
  const propriedades=fontes.find(x=>x.file===cfg.arquivo&&x.sheet==='propriedades');
  const prop=propriedades?new Map(propriedades.cells.map(x=>[`${x.r},${x.c}`,x.v])):null;
  for (let i=0;i<cfg.nc;i++) {
    const cell=cel(1,i+2);
    let grupo=cfg.animal,cor='#D55E00',evidencia='Eixo das colunas e cor dos nomes';
    if (cfg.rede==='dispersao') {
      const nomeProp=limpar(prop.get(`${i+2},1`).replaceAll('_',' '));
      const grupoProp=prop.get(`${i+2},2`);
      if (nomeProp!==colunas[i]) throw Error('Categoria desalinhada');
      grupo=grupoProp==='aves'?'Aves':'Morcegos';
      const corEsperada=grupo==='Aves'?'#0000D4':'#DD0806';
      if(cell.font!==corEsperada) throw Error('Cor diferente da classificação');
      cor=grupo==='Aves'?'#0072B2':'#D55E00';
      evidencia=`propriedades!B${i+2}; legenda dados!U3:U4 e cor da fonte`;
    }
    categorias.push([colunas[i],colunas[i],cfg.animal,grupo,cor,cell.v,cell.font,cell.fill,`${cfg.aba}!${letra(i+2)}1`,evidencia,'']);
  }
  for (const [tipo,rows] of [['matriz',matriz],['categorias',categorias]]) {
    const sheet=wb.worksheets.add(`${cfg.rede}_${tipo}`);
    const range=sheet.getRangeByIndexes(0,0,rows.length,rows[0].length);
    range.values=rows;
    sheet.getRangeByIndexes(0,0,1,rows[0].length).format.font={bold:true,name:'Arial'};
    const lidos=range.values;
    if(JSON.stringify(lidos)!==JSON.stringify(rows)) throw Error('Erro na transferência para a tabela');
    await fs.writeFile(`data/${cfg.rede}_${tipo}.csv`,csv(lidos),'utf8');
    if(tipo==='categorias') {
      sheet.getRange('A:D').format.columnWidth=27;
      sheet.getRange('E:E').format.columnWidth=13;
      for(let k=1;k<rows.length;k++) sheet.getCell(k,4).format.fill=rows[k][4];
      const img=await wb.render({sheetName:sheet.name,range:`A1:E${Math.min(rows.length,14)}`,scale:1,format:'png'});
      await fs.writeFile(`.preparo/${cfg.rede}_categorias.png`,new Uint8Array(await img.arrayBuffer()));
    }
  }
  auditoria.push({rede:cfg.rede,linhas:cfg.nr,colunas:cfg.nc,ligacoes:valores.flat().filter(x=>x>0).length,total:valores.flat().reduce((a,b)=>a+b,0),grupos:Object.fromEntries([...new Set(categorias.slice(1).map(x=>x[3]))].map(g=>[g,categorias.slice(1).filter(x=>x[3]===g).length]))});
}
const cabecalho=['rede','arquivo','aba','intervalo','tipo','animal','titulo','unidade','referencia','nota'];
const metadados=[cabecalho,...configuracoes.map(x=>cabecalho.map(k=>x[k]))];
const meta=wb.worksheets.add('redes');
meta.getRangeByIndexes(0,0,metadados.length,cabecalho.length).values=metadados;
wb.recalculate();
await fs.writeFile('data/redes.csv',csv(meta.getUsedRange().values),'utf8');
await fs.writeFile('.preparo/auditoria_csv.json',JSON.stringify(auditoria,null,2),'utf8');
console.log(JSON.stringify(auditoria,null,2));
